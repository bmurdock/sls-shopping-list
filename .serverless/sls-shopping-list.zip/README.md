# Serverless SMS-Controlled Shopping List

## Caution
**This project likely is impractically expensive (even to test) due to Twilio SMS costs

## Setup
### Twilio